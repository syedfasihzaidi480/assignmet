function displayMessage(message){
    alert(message)
}